/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package ca.sheridancollege.project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author fairy
 */
public class GoFishPlayerCardsTest {
    
    public GoFishPlayerCardsTest() {
    }
    
    @BeforeEach
    public void setUp() {
    }

    /**
     * Test of setCards method, of class GoFishPlayerCards.
     */
    @Test
    public void testSetCards() {
        System.out.println("setCards");
        GoFishPlayerCards instance = new GoFishPlayerCards();
        instance.setCards();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setHand method, of class GoFishPlayerCards.
     */
    @Test
    public void testSetHand() {
        System.out.println("setHand");
        GoFishPlayerCards instance = new GoFishPlayerCards();
        instance.setHand();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showUsrCard method, of class GoFishPlayerCards.
     */
    @Test
    public void testShowUsrCard() {
        System.out.println("showUsrCard");
       
        GoFishPlayerCards instance = new GoFishPlayerCards();
        instance.showUsrCard();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }


  
   

    /**
     * Test of win method, of class GoFishPlayerCards.
     */
    @Test
    public void testWinGood() {
        int m=5;
        System.out.println("win");
        GoFishPlayerCards instance = new GoFishPlayerCards();
        instance.win();
    }
    
    @Test
    public void testWinBad() {
         int m=0;
        System.out.println("lose");
        GoFishPlayerCards instance = new GoFishPlayerCards();
        instance.win();
    }
    
    @Test
    public void testWinBoundary() {
         int m=4;
        System.out.println("tie");
        GoFishPlayerCards instance = new GoFishPlayerCards();
        instance.win();
    }
    
}
