package ca.sheridancollege.project;
// @author cuteagrawal
import java.util.*;

public class GoFishPlayerCards {
    Scanner in = new Scanner(System.in);
    Random rand = new Random();
    public List<Integer> list = new ArrayList<>();
    public ArrayList<Integer> usrHand = new ArrayList<Integer>();
    public ArrayList<Integer> compHand = new ArrayList<Integer>();

    //add cards to the deck and shuffles them
    public void setCards(){
        int k = 1;
        while(k < 5){
            for (int i = 1; i <=13; ++i){
                list.add(i);
            }
            k++;
        }
        Collections.shuffle(list, rand);
        System.out.println(list);

    }

    //distribute cards to the user and computer
    public void setHand(){
        for(int i = 0; i < 5; i++){
            usrHand.add(list.get(i));
        }
        for(int j = 5; j < 10; j++){
            compHand.add(list.get(j));
        }
        System.out.println(usrHand);
        System.out.println(compHand);
    }

    //displays the cards to the user
    public void showUsrCard(){
        //System.out.println("User hand size: " + usrHand.size());
        System.out.print("Your cards:");
        for(int i = 0; i < usrHand.size(); i++){

            switch(usrHand.get(i)) {
                case (1):
                    System.out.print(" | Ace | ");
                    break;
                case (11):
                    System.out.print(" | Jack | ");
                    break;
                case (12):
                    System.out.print(" | Queen | ");
                    break;
                case (13):
                    System.out.print(" | King | ");
                    break;
                default:
                    System.out.print(" | " + usrHand.get(i) + " | ");
            }
        }
        System.out.println("");

    }

    //
    public void chooseCard(){
        int val;
        System.out.println("Select the card you want");
        String input = in.next();
        System.out.println(input);

        //sets the input into a variable called val
        if(input.matches("Ace")){
            val = 1;
        } else if (input.matches("Jack")){
            val = 11;
        } else if (input.matches("Queen")){
            val = 12;
        } else if (input.matches("King")){
            val = 13;
        } else {
            val = Integer.parseInt(input);
        }
        //verifies if choosen card is in the hand or not
        int chosen = -1;
        for(int i = 0; i < usrHand.size(); i++){
            if(val == usrHand.get(i)){
                System.out.println("ver");
                chosen = i;
                break;
            }
        }
        if(chosen >= 0){
            System.out.println("ok");
            process(val);
        } else{
            System.out.println("Sorry you don't have that card in your hand. "
                                + "You tried to cheat. You have to start over" );
        }

    }

    public void process(int m){
        System.out.println(list.size());

        int var = ( usrHand.size() + compHand.size() ) ;
        //int var =( list.size() - ( usrHand.size() + compHand.size() ) ) - 1; //checks list size - 1
        for(int i = 0; i < compHand.size(); i++){
            if(m == compHand.get(i)){
                System.out.println("yup");
                break;
            } else {
                System.out.println("var is " + var);
                usrHand.add(list.get(var));
                list.remove(var);
                System.out.println(list);
                break;
            }
        }
        showUsrCard();
    }

    //checks if the user has one type of four cards
    public void win(){

        int m = 0;
        for(int i = 0; i < usrHand.size(); i++){
            if (usrHand.get(0) == usrHand.get(i)){
                m++;
            }
        }
        System.out.println("m is " + m);
    }
    
}


