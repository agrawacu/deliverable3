package ca.sheridancollege.project;

// @author cuteagrawal
public class GoFishMain {
    public static void main(String args[]){

        GoFishGame obj1 = new GoFishGame("GoFish Card Game");
        GoFishPlayerCards obj2 = new GoFishPlayerCards();

        System.out.println("Welcome to " + obj1.getName());
        obj2.setCards();
        obj2.setHand();
        obj2.showUsrCard();
        //obj2.chooseCard();
        obj2.win();
    }
}
