/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package ca.sheridancollege.project;

/**
 * This class
 *
 * @author 
 */
public class GoFishGame extends Game {

    public GoFishGame(String name){
        //constructor
        super(name);
    }

    @Override
    public void play(){

    }

    @Override
    public void declareWinner(){

    }


}
